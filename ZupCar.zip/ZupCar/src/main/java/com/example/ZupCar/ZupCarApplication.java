package com.example.ZupCar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZupCarApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZupCarApplication.class, args);
	}

}
